﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BoardofPardons.Entity
{
    public partial class User
    {
        public string Password { get; set; }
    }
}
